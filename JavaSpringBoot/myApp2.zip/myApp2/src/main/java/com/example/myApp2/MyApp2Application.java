package com.example.myApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(MyApp2Application.class, args);
	}

}
